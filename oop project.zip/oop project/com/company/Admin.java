package com.company;

import java.io.*;
import java.util.Scanner;

public class Admin {
    void displayAdminMenu() {
        System.out.println("Menu \n");
        System.out.println("01  ADMIN PERSONAL INFO ");
        System.out.println("02  CHECK STAFF LATEST LEAVE APPLICATION ");
        System.out.println("00  EXIT SYSTEM \n");
    }

    void PersonalInfo_01() {

        System.out.println("YOUR PERSONAL INFO \n");
        System.out.println("NAME: ABU BIN AMIR ");
        System.out.println("AGE:   38");
        System.out.println("DATE OF BIRTH: 3 MAC 1983 ");
        System.out.println("POSITION: HUMAN RESOURCE MANAGER ");
        System.out.println("EMAIL ADDRESS: abubinamir@gmail.com ");
        System.out.println("HOME ADDRESS: TAMAN WIRAJAYA KOTA  KINABALU ");
        System.out.println();

    }

}
