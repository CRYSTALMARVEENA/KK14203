
package Project2;

import java.awt.event.WindowEvent;
import java.io.FileWriter;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import java.io.*;

public class StaffApplyLeave extends javax.swing.JFrame {
   
    public StaffApplyLeave() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        leaveForm_label = new javax.swing.JLabel();
        leaveForm_panel = new javax.swing.JPanel();
        fullname_label = new javax.swing.JLabel();
        staffID_label = new javax.swing.JLabel();
        leaveType_label = new javax.swing.JLabel();
        staffID_input = new javax.swing.JTextField();
        fullname_input = new javax.swing.JTextField();
        dateStart_label = new javax.swing.JLabel();
        dateEnd_leave = new javax.swing.JLabel();
        confirm_button = new javax.swing.JButton();
        exit_button = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        leaveDetails_txtarea = new javax.swing.JTextArea();
        leaveDetails_Output = new javax.swing.JLabel();
        leaveType_combox = new javax.swing.JComboBox<>();
        dateStart_input = new javax.swing.JTextField();
        dateEnd_input = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("HC00 COMPANY LEAVE MANAGEMENT SYSTEM");

        leaveForm_label.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        leaveForm_label.setText("STAFF LEAVE APPLICATION FORM");

        leaveForm_panel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        fullname_label.setText("FULL NAME");

        staffID_label.setText("STAFF ID");

        leaveType_label.setText("TYPE OF LEAVE");

        dateStart_label.setText("DATE START LEAVE");

        dateEnd_leave.setText("DATE END LEAVE");

        confirm_button.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        confirm_button.setText("CONFIRM");
        confirm_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirm_buttonActionPerformed(evt);
            }
        });

        exit_button.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        exit_button.setText("EXIT");
        exit_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exit_buttonActionPerformed(evt);
            }
        });

        leaveDetails_txtarea.setColumns(20);
        leaveDetails_txtarea.setRows(5);
        jScrollPane1.setViewportView(leaveDetails_txtarea);

        leaveDetails_Output.setText("LEAVE DETAILS");

        leaveType_combox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "[SELECT]", "ANNUAL LEAVE", "MEDICAL LEAVE", "MATERNITY LEAVE", "PUBLIC HOLIDAYS", "EMERGENCY LEAVE" }));
        leaveType_combox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                leaveType_comboxActionPerformed(evt);
            }
        });

        dateStart_input.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dateStart_inputActionPerformed(evt);
            }
        });

        jLabel1.setText("(e.g 8/12/2020)");

        jLabel2.setText("(e.g 8/12/2020)");

        javax.swing.GroupLayout leaveForm_panelLayout = new javax.swing.GroupLayout(leaveForm_panel);
        leaveForm_panel.setLayout(leaveForm_panelLayout);
        leaveForm_panelLayout.setHorizontalGroup(
            leaveForm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leaveForm_panelLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(leaveForm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(staffID_label)
                    .addComponent(fullname_label, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dateEnd_leave, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(dateStart_label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(leaveType_label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(leaveDetails_Output, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(leaveForm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(leaveForm_panelLayout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 573, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                        .addGroup(leaveForm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(confirm_button)
                            .addComponent(exit_button, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(24, Short.MAX_VALUE))
                    .addGroup(leaveForm_panelLayout.createSequentialGroup()
                        .addGroup(leaveForm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(leaveForm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(fullname_input, javax.swing.GroupLayout.DEFAULT_SIZE, 575, Short.MAX_VALUE)
                                .addComponent(staffID_input))
                            .addComponent(leaveType_combox, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(leaveForm_panelLayout.createSequentialGroup()
                                .addComponent(dateStart_input, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(leaveForm_panelLayout.createSequentialGroup()
                                .addComponent(dateEnd_input, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        leaveForm_panelLayout.setVerticalGroup(
            leaveForm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leaveForm_panelLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(leaveForm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(staffID_input, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(staffID_label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(leaveForm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(fullname_label, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(fullname_input, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(leaveForm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(leaveType_combox, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(leaveType_label))
                .addGap(18, 18, 18)
                .addGroup(leaveForm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dateStart_label)
                    .addComponent(dateStart_input, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(leaveForm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dateEnd_leave)
                    .addComponent(dateEnd_input)
                    .addComponent(jLabel2))
                .addGroup(leaveForm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(leaveForm_panelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(confirm_button, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(exit_button, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(172, Short.MAX_VALUE))
                    .addGroup(leaveForm_panelLayout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(leaveForm_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(leaveDetails_Output, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(58, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(317, 317, 317)
                        .addComponent(leaveForm_label))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(leaveForm_panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(38, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(leaveForm_label, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                .addComponent(leaveForm_panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void confirm_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirm_buttonActionPerformed
        
        String leaveType_selected = (String) leaveType_combox.getSelectedItem();
        leaveDetails_txtarea.append("Staff Leave Application Details" + "\n");
        leaveDetails_txtarea.append( "\n"+"STAFF ID: " + staffID_input.getText() + "\n" + "FULLNAME: " + fullname_input.getText() + "\n" + "TYPE OF LEAVE: " + leaveType_selected + "\n" + "DATE START LEAVE: " + dateStart_input.getText() + "\n" + "DATE END LEAVE: "+ dateEnd_input.getText() );
        JOptionPane.showMessageDialog(null," Leave Application is successfully recorded.", "Valid Application", JOptionPane.DEFAULT_OPTION);
 
        //write data into new text file     
        File file = new File(filepath);
        FileWriter fr = null;
        BufferedWriter br = null;
        PrintWriter pr = null;
        
        String lines;
        lines = "\n"+"Staff ID: " + staffID_input.getText() + "\n" + "Full Name: " + fullname_input.getText() + "\n" + "Type of Leave: " + leaveType_selected + "\n" + "Date Start Leave: " + dateStart_input.getText() + "\n" + "Date End Leave: "+ dateEnd_input.getText() + "\n";
        
        //exception handling
        try {
			// to append to file, you need to initialize FileWriter using below constructor
			fr = new FileWriter(file, true);
			br = new BufferedWriter(fr);
			pr = new PrintWriter(br);
			pr.println(lines);
                        
                        br.close();
                        pr.close();
                        fr.close();      
            } 
        catch (IOException e) {
                        JOptionPane.showMessageDialog(null,"Application unsuccessful", "Invalid Application", JOptionPane.ERROR_MESSAGE);
            
    }

        
        
    }//GEN-LAST:event_confirm_buttonActionPerformed

    private void exit_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exit_buttonActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exit_buttonActionPerformed

    private void dateStart_inputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dateStart_inputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dateStart_inputActionPerformed

    private void leaveType_comboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_leaveType_comboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_leaveType_comboxActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(StaffApplyLeave.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(StaffApplyLeave.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(StaffApplyLeave.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(StaffApplyLeave.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StaffApplyLeave().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton confirm_button;
    private javax.swing.JTextField dateEnd_input;
    private javax.swing.JLabel dateEnd_leave;
    private javax.swing.JTextField dateStart_input;
    private javax.swing.JLabel dateStart_label;
    private javax.swing.JButton exit_button;
    private javax.swing.JTextField fullname_input;
    private javax.swing.JLabel fullname_label;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel leaveDetails_Output;
    private javax.swing.JTextArea leaveDetails_txtarea;
    private javax.swing.JLabel leaveForm_label;
    private javax.swing.JPanel leaveForm_panel;
    private javax.swing.JComboBox<String> leaveType_combox;
    private javax.swing.JLabel leaveType_label;
    private javax.swing.JTextField staffID_input;
    private javax.swing.JLabel staffID_label;
    // End of variables declaration//GEN-END:variables

    //global variable
    String leaveType_selected = "";
    String dayStart_selected = "";
    String monthStart_selected = "";
    String yearStart_selected = "";
    String dayEnd_selected = "";
    String monthEnd_selected = "";
    String yearEnd_selected = "";
    String leave_details = "";
    String filepath ="New Leave Application.txt"; // in the same directory
    
  
private void systemExit()
    {
    WindowEvent winCloseing = new WindowEvent(this, WindowEvent.WINDOW_CLOSING);
    }

   
}
