
package Project2;

import java.awt.event.WindowEvent;
import java.io.*;
import java.util.Scanner;
import java.io.FileNotFoundException;
import javax.swing.JOptionPane;

public class AdminLeaveApproval extends javax.swing.JFrame {

   
    public AdminLeaveApproval() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        adminApproval_label = new javax.swing.JLabel();
        leaveApproval_panel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        loadReq_textArea = new javax.swing.JTextArea();
        load_button = new javax.swing.JButton();
        leaveApproval_label = new javax.swing.JLabel();
        authorise_button = new javax.swing.JButton();
        exit_button = new javax.swing.JButton();
        leaveApproval_combox = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("HC00 COMPANY LEAVE MANAGEMENT SYSTEM");

        adminApproval_label.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminApproval_label.setText("STAFF LEAVE APPROVAL ");

        leaveApproval_panel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        loadReq_textArea.setColumns(20);
        loadReq_textArea.setRows(5);
        jScrollPane1.setViewportView(loadReq_textArea);

        load_button.setText("LOAD REQUEST");
        load_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                load_buttonActionPerformed(evt);
            }
        });

        leaveApproval_label.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        leaveApproval_label.setText("LEAVE APPROVAL");

        authorise_button.setText("AUTHORISE");
        authorise_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                authorise_buttonActionPerformed(evt);
            }
        });

        exit_button.setText("EXIT");
        exit_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exit_buttonActionPerformed(evt);
            }
        });

        leaveApproval_combox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "[SELECT APPROVAL MESSAGE]", "(LEAVE REQUEST IS APPROVED)", "(LEAVE REQUEST IS  DISAPPROVED)" }));
        leaveApproval_combox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                leaveApproval_comboxActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout leaveApproval_panelLayout = new javax.swing.GroupLayout(leaveApproval_panel);
        leaveApproval_panel.setLayout(leaveApproval_panelLayout);
        leaveApproval_panelLayout.setHorizontalGroup(
            leaveApproval_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leaveApproval_panelLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(leaveApproval_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(leaveApproval_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(exit_button, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(authorise_button, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(leaveApproval_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(leaveApproval_panelLayout.createSequentialGroup()
                            .addGap(10, 10, 10)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 534, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(load_button)
                        .addGroup(leaveApproval_panelLayout.createSequentialGroup()
                            .addComponent(leaveApproval_label)
                            .addGap(34, 34, 34)
                            .addComponent(leaveApproval_combox, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(36, Short.MAX_VALUE))
        );
        leaveApproval_panelLayout.setVerticalGroup(
            leaveApproval_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leaveApproval_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(load_button, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(leaveApproval_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(leaveApproval_label, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(leaveApproval_combox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addComponent(authorise_button)
                .addGap(18, 18, 18)
                .addComponent(exit_button)
                .addGap(11, 11, 11))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(206, 206, 206)
                        .addComponent(adminApproval_label, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(leaveApproval_panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(25, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(adminApproval_label, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(leaveApproval_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(32, 32, 32))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void authorise_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_authorise_buttonActionPerformed
        StringBuilder sb = new StringBuilder();
                    String strLine = "";
                    try { 
                        String filename = "New Leave Application.txt";
                        FileWriter fw = new FileWriter(filename, true);
                        String leaveApproval_selected = (String) leaveApproval_combox.getSelectedItem();
                        String lineGap = " ";
                        sb.append(System.lineSeparator());
            
                        //appends the string to the file
                        fw.write(lineGap + leaveApproval_selected + sb.append(System.lineSeparator()));
                        fw.close();
                        JOptionPane.showMessageDialog(null,"Staff leave application has been authorised.", "Status of Approval", JOptionPane.DEFAULT_OPTION);                 
                    } 
                    catch (IOException ioe) {
                        JOptionPane.showMessageDialog(null," Approval cannot be done", "Approval Error", JOptionPane.ERROR_MESSAGE);
                    }

    }//GEN-LAST:event_authorise_buttonActionPerformed

    private void load_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_load_buttonActionPerformed
        
      try {
                  File myObj = new File("New Leave Application.txt");
                  Scanner myReader = new Scanner(myObj);
                  while (myReader.hasNextLine()) {
                      String data = myReader.nextLine();
                      loadReq_textArea.append(data);
                  }
                  myReader.close();
              } catch (FileNotFoundException e) {
                  JOptionPane.showMessageDialog(null," File not exist.", "No new leave request found", JOptionPane.DEFAULT_OPTION);                  
                  e.printStackTrace();
              }

       
     
    }//GEN-LAST:event_load_buttonActionPerformed

    private void leaveApproval_comboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_leaveApproval_comboxActionPerformed
        
    }//GEN-LAST:event_leaveApproval_comboxActionPerformed

    private void exit_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exit_buttonActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exit_buttonActionPerformed

    
    public static void main(String args[])  {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminLeaveApproval.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminLeaveApproval.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminLeaveApproval.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminLeaveApproval.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminLeaveApproval().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel adminApproval_label;
    private javax.swing.JButton authorise_button;
    private javax.swing.JButton exit_button;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> leaveApproval_combox;
    private javax.swing.JLabel leaveApproval_label;
    private javax.swing.JPanel leaveApproval_panel;
    private javax.swing.JTextArea loadReq_textArea;
    private javax.swing.JButton load_button;
    // End of variables declaration//GEN-END:variables

    private void systemExit(){
        WindowEvent winCloseing = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
    }
}
